//程序名称： Storm虚拟风洞 
//可执行文件名称：storm_vwt.elf (Linux),  storm_vwt.exe(Windows)
//最近一次修改：16:59 2021/6/20 星期日

#include<stdio.h>
#include<stdlib.h>
#include<math.h>    //编译选项加"-lm"
#include<pthread.h> //加"-lpthread".此代码仅能在Linux上或Windows MinGW上编译.
#include<time.h>
//注意，此程序的Windows版本需要同目录下的"libwinpthread-1.dll"才能执行。 

//自带库 
#include"../include/syscompile.h"
#include"storm_vwt.h"

struct Airmols{
	double      xyz[3];
	float      vxyz[3];
	int           mode;
};
